import React, { useState } from 'react';
import {
  Shield,
  Zap,
  Gauge,
  Flame,
  Snowflake,
  Crosshair,
  Check,
  Play,
  ArrowRight,
  Globe,
  Award,
} from 'lucide-react';
import { TankConfig } from '../types';
import { TANK_ROSTER, BIOMES, BiomeConfig } from '../game/constants';
import { soundManager } from '../audio/soundManager';

interface TankSelectModalProps {
  mode: 'single' | 'twoplayer' | 'practice';
  initialP1TankId: string;
  initialP2TankId: string;
  initialBiomeId: string;
  onStartMatch: (p1TankId: string, p2TankId: string, biomeId: string) => void;
  onCancel: () => void;
}

export const TankSelectModal: React.FC<TankSelectModalProps> = ({
  mode,
  initialP1TankId,
  initialP2TankId,
  initialBiomeId,
  onStartMatch,
  onCancel,
}) => {
  const [selectedP1, setSelectedP1] = useState<string>(initialP1TankId);
  const [selectedP2, setSelectedP2] = useState<string>(initialP2TankId);
  const [selectedBiome, setSelectedBiome] = useState<string>(initialBiomeId);
  const [activeTab, setActiveTab] = useState<'p1' | 'p2' | 'biome'>('p1');

  const p1Tank = TANK_ROSTER.find((t) => t.id === selectedP1) || TANK_ROSTER[0];
  const p2Tank = TANK_ROSTER.find((t) => t.id === selectedP2) || TANK_ROSTER[1];
  const currentTank = activeTab === 'p1' ? p1Tank : p2Tank;

  const handleStart = () => {
    soundManager.playClick();
    onStartMatch(selectedP1, selectedP2, selectedBiome);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col gap-6 text-white max-h-[95vh] overflow-y-auto">
        {/* MODAL HEADER */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-amber-500 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                ALL TANKS UNLOCKED
              </span>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                {mode === 'single' ? 'SELECT YOUR TANK & ARENA' : 'PASS & PLAY TANK DRAFT'}
              </h2>
            </div>
            <p className="text-slate-400 text-sm mt-0.5">
              Choose your war machine with custom weapons, stats, and battlefield terrain.
            </p>
          </div>

          {/* TAB TOGGLES FOR 2 PLAYER */}
          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 self-start sm:self-auto">
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('p1');
              }}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-1.5 ${
                activeTab === 'p1' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Player 1 (Blue)
            </button>
            {mode === 'twoplayer' && (
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('p2');
                }}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-1.5 ${
                  activeTab === 'p2' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Player 2 (Red)
              </button>
            )}
            {mode === 'single' && (
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('p2');
                }}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-1.5 ${
                  activeTab === 'p2' ? 'bg-red-600/80 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Enemy AI Tank
              </button>
            )}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('biome');
              }}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-1.5 ${
                activeTab === 'biome' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" /> Arena
            </button>
          </div>
        </div>

        {/* TAB 1 & 2: TANK ROSTER SELECTION */}
        {activeTab !== 'biome' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* LEFT: TANK CARDS GRID (9 TANKS) */}
            <div className="lg:col-span-7 grid grid-cols-3 gap-3">
              {TANK_ROSTER.map((tank) => {
                const isSelected = activeTab === 'p1' ? selectedP1 === tank.id : selectedP2 === tank.id;
                return (
                  <button
                    key={tank.id}
                    id={`select-tank-${tank.id}`}
                    onClick={() => {
                      soundManager.playClick();
                      if (activeTab === 'p1') setSelectedP1(tank.id);
                      else setSelectedP2(tank.id);
                    }}
                    className={`relative p-3 rounded-2xl border flex flex-col items-start gap-2 text-left transition-all active:scale-95 group ${
                      isSelected
                        ? 'bg-gradient-to-b from-slate-800 to-slate-900 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)] ring-2 ring-amber-400/40'
                        : 'bg-slate-950/80 hover:bg-slate-800/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    {/* Tank Accent Color Strip */}
                    <div className="w-full flex items-center justify-between">
                      <span
                        className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md"
                        style={{ backgroundColor: `${tank.glowColor}25`, color: tank.glowColor }}
                      >
                        {tank.category}
                      </span>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-black">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>

                    <div className="mt-1">
                      <div className="font-extrabold text-sm sm:text-base text-white group-hover:text-amber-300 transition">
                        {tank.name}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[120px]">{tank.tagline}</div>
                    </div>

                    {/* Mini Stats Indicator */}
                    <div className="w-full flex items-center gap-1 mt-auto pt-1 border-t border-slate-800/80 text-[10px] text-slate-400">
                      <Flame className="w-3 h-3 text-orange-400" />
                      <span>{tank.stats.damage} DMG</span>
                      <span className="mx-0.5">•</span>
                      <Shield className="w-3 h-3 text-blue-400" />
                      <span>{tank.stats.health} HP</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* RIGHT: SELECTED TANK INSPECTOR */}
            <div className="lg:col-span-5 bg-slate-950/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col gap-4">
              <div className="border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full animate-ping"
                    style={{ backgroundColor: currentTank.glowColor }}
                  />
                  <h3 className="text-xl font-black text-white">{currentTank.name}</h3>
                </div>
                <p className="text-xs text-amber-400 font-semibold mt-0.5">{currentTank.tagline}</p>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">{currentTank.description}</p>
              </div>

              {/* STATS BARS */}
              <div className="flex flex-col gap-2">
                <div className="text-xs font-black uppercase tracking-wider text-slate-400">COMBAT RATINGS</div>

                {/* Health Bar */}
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="flex items-center gap-1.5 text-blue-300">
                    <Shield className="w-3.5 h-3.5 text-blue-400" /> HEALTH
                  </span>
                  <span className="font-mono text-white">{currentTank.stats.health} HP</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${(currentTank.stats.health / 1400) * 100}%` }}
                  />
                </div>

                {/* Damage Bar */}
                <div className="flex items-center justify-between text-xs font-bold mt-1">
                  <span className="flex items-center gap-1.5 text-orange-300">
                    <Flame className="w-3.5 h-3.5 text-orange-400" /> DAMAGE
                  </span>
                  <span className="font-mono text-white">{currentTank.stats.damage} / 100</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-orange-500 rounded-full"
                    style={{ width: `${currentTank.stats.damage}%` }}
                  />
                </div>

                {/* Mobility Bar */}
                <div className="flex items-center justify-between text-xs font-bold mt-1">
                  <span className="flex items-center gap-1.5 text-emerald-300">
                    <Gauge className="w-3.5 h-3.5 text-emerald-400" /> MOBILITY
                  </span>
                  <span className="font-mono text-white">{currentTank.stats.mobility} / 100</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full"
                    style={{ width: `${currentTank.stats.mobility}%` }}
                  />
                </div>
              </div>

              {/* ARSENAL LIST */}
              <div className="flex flex-col gap-2 mt-1">
                <div className="text-xs font-black uppercase tracking-wider text-slate-400">SIGNATURE ARSENAL</div>
                <div className="flex flex-col gap-1.5">
                  {currentTank.weapons.map((w, idx) => (
                    <div
                      key={w.id}
                      className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-2.5 flex items-start gap-2.5"
                    >
                      <div
                        className="p-2 rounded-lg font-black text-xs shrink-0"
                        style={{ backgroundColor: `${w.color}25`, color: w.color }}
                      >
                        #{idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-white">{w.name}</span>
                          <span className="text-[10px] font-mono text-amber-300 font-bold">
                            {w.damage} DMG • RAD {w.blastRadius}m
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{w.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* TAB 3: ARENA & BIOME SELECTION */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 py-2">
            {BIOMES.map((b) => {
              const isSelected = selectedBiome === b.id;
              return (
                <button
                  key={b.id}
                  id={`select-biome-${b.id}`}
                  onClick={() => {
                    soundManager.playClick();
                    setSelectedBiome(b.id);
                  }}
                  className={`p-4 rounded-2xl border flex flex-col gap-3 text-left transition-all active:scale-95 ${
                    isSelected
                      ? 'bg-slate-800 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)] ring-2 ring-emerald-400/40'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-900'
                  }`}
                >
                  <div
                    className="w-full h-24 rounded-xl border border-slate-700/60 shadow-inner flex items-end p-2.5"
                    style={{
                      background: `linear-gradient(to bottom, ${b.skyColor}, ${b.groundColor})`,
                    }}
                  >
                    <span className="text-xs font-black uppercase text-white drop-shadow">{b.name}</span>
                  </div>
                  <div>
                    <div className="font-extrabold text-sm text-white">{b.name}</div>
                    <div className="text-xs text-slate-400 mt-0.5">Destructible 3D landscape with dynamic lighting.</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* MODAL FOOTER */}
        <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-2">
          <button
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl font-bold text-sm text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 transition active:scale-95"
          >
            Back to Menu
          </button>

          <button
            id="btn-confirm-start-battle"
            onClick={handleStart}
            className="px-8 py-3 rounded-2xl font-black text-base tracking-wider uppercase text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-[0_0_20px_rgba(245,158,11,0.5)] transition active:scale-95 flex items-center gap-2"
          >
            <Play className="w-4 h-4 fill-slate-950" /> START BATTLE
          </button>
        </div>
      </div>
    </div>
  );
};
