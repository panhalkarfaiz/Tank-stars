import * as THREE from 'three';

interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  gravity: number;
  drag: number;
  scaleDelta: number;
  rotSpeed: number;
  type: 'spark' | 'smoke' | 'debris' | 'shockwave' | 'flame' | 'plasma';
}

export class ParticleSystem {
  public scene: THREE.Scene;
  private particles: Particle[] = [];

  // Reusable materials & geometries for peak performance
  private sparkGeo = new THREE.SphereGeometry(0.12, 6, 6);
  private smokeGeo = new THREE.DodecahedronGeometry(0.35, 1);
  private debrisGeo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
  private shockwaveGeo = new THREE.RingGeometry(0.1, 0.5, 32);

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.shockwaveGeo.rotateX(-Math.PI / 2);
  }

  public emitMuzzleFlash(pos: THREE.Vector3, dir: THREE.Vector3, color: string = '#ffaa00') {
    // Flash core
    const flashMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(color),
      transparent: true,
      opacity: 0.9,
    });
    const flash = new THREE.Mesh(this.sparkGeo, flashMat);
    flash.position.copy(pos);
    flash.scale.set(3.0, 3.0, 3.0);
    this.scene.add(flash);

    this.particles.push({
      mesh: flash,
      vx: dir.x * 3,
      vy: dir.y * 3,
      vz: dir.z * 3,
      life: 0.08,
      maxLife: 0.08,
      gravity: 0,
      drag: 0.9,
      scaleDelta: -25,
      rotSpeed: 0,
      type: 'flame',
    });

    // Muzzle sparks
    for (let i = 0; i < 8; i++) {
      const sparkMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(color),
      });
      const spark = new THREE.Mesh(this.sparkGeo, sparkMat);
      spark.position.copy(pos);
      this.scene.add(spark);

      const spread = 0.5;
      this.particles.push({
        mesh: spark,
        vx: (dir.x + (Math.random() - 0.5) * spread) * (8 + Math.random() * 8),
        vy: (dir.y + (Math.random() - 0.5) * spread) * (8 + Math.random() * 8),
        vz: (dir.z + (Math.random() - 0.5) * spread) * (8 + Math.random() * 8),
        life: 0.2 + Math.random() * 0.15,
        maxLife: 0.35,
        gravity: -10,
        drag: 0.92,
        scaleDelta: -2.5,
        rotSpeed: 0,
        type: 'spark',
      });
    }
  }

  public emitTrailParticle(pos: THREE.Vector3, color: string, type: string) {
    const mat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(color),
      transparent: true,
      opacity: 0.7,
    });
    const mesh = new THREE.Mesh(this.smokeGeo, mat);
    mesh.position.set(
      pos.x + (Math.random() - 0.5) * 0.2,
      pos.y + (Math.random() - 0.5) * 0.2,
      pos.z + (Math.random() - 0.5) * 0.2
    );
    this.scene.add(mesh);

    this.particles.push({
      mesh,
      vx: (Math.random() - 0.5) * 0.5,
      vy: Math.random() * 0.5,
      vz: (Math.random() - 0.5) * 0.5,
      life: 0.4 + Math.random() * 0.3,
      maxLife: 0.7,
      gravity: 1.0, // slight rise
      drag: 0.95,
      scaleDelta: 0.8,
      rotSpeed: Math.random() * 2 - 1,
      type: 'smoke',
    });
  }

  public emitExplosion(
    x: number,
    y: number,
    z: number,
    radius: number,
    colorHex: string,
    isColossal: boolean = false
  ) {
    const pos = new THREE.Vector3(x, y, z);
    const count = isColossal ? 70 : 35;
    const expColor = new THREE.Color(colorHex);

    // Shockwave Ring
    const shockMat = new THREE.MeshBasicMaterial({
      color: expColor,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    const shockwave = new THREE.Mesh(this.shockwaveGeo, shockMat);
    shockwave.position.set(x, y + 0.1, z);
    shockwave.scale.set(1, 1, 1);
    this.scene.add(shockwave);

    this.particles.push({
      mesh: shockwave,
      vx: 0,
      vy: 0,
      vz: 0,
      life: isColossal ? 0.8 : 0.45,
      maxLife: isColossal ? 0.8 : 0.45,
      gravity: 0,
      drag: 1,
      scaleDelta: (radius * (isColossal ? 18 : 12)),
      rotSpeed: 0,
      type: 'shockwave',
    });

    // Fireball center core
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
    });
    const core = new THREE.Mesh(this.sparkGeo, coreMat);
    core.position.copy(pos);
    core.scale.set(radius * 1.5, radius * 1.5, radius * 1.5);
    this.scene.add(core);

    this.particles.push({
      mesh: core,
      vx: 0,
      vy: isColossal ? 2 : 0.5,
      vz: 0,
      life: isColossal ? 0.6 : 0.25,
      maxLife: isColossal ? 0.6 : 0.25,
      gravity: 0,
      drag: 0.9,
      scaleDelta: isColossal ? 4 : -5,
      rotSpeed: 0,
      type: 'flame',
    });

    // Flying debris chunks
    for (let i = 0; i < count; i++) {
      const debrisMat = new THREE.MeshStandardMaterial({
        color: Math.random() > 0.4 ? expColor : new THREE.Color(0x332211),
        roughness: 0.9,
      });
      const debris = new THREE.Mesh(this.debrisGeo, debrisMat);
      debris.position.copy(pos);
      this.scene.add(debris);

      const angle = Math.random() * Math.PI * 2;
      const elevation = Math.random() * Math.PI * 0.45 + 0.1;
      const speed = (isColossal ? 14 : 9) * (0.5 + Math.random() * 0.8);

      this.particles.push({
        mesh: debris,
        vx: Math.cos(angle) * Math.cos(elevation) * speed,
        vy: Math.sin(elevation) * speed * 1.2,
        vz: Math.sin(angle) * Math.cos(elevation) * speed * 0.5,
        life: 0.8 + Math.random() * 0.8,
        maxLife: 1.6,
        gravity: -18,
        drag: 0.97,
        scaleDelta: -0.15,
        rotSpeed: (Math.random() - 0.5) * 10,
        type: 'debris',
      });
    }

    // Rising Smoke Plumes
    const smokeCount = isColossal ? 25 : 12;
    for (let i = 0; i < smokeCount; i++) {
      const sMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(0x222222),
        transparent: true,
        opacity: 0.6,
      });
      const sMesh = new THREE.Mesh(this.smokeGeo, sMat);
      sMesh.position.set(
        x + (Math.random() - 0.5) * radius,
        y + Math.random() * (radius * 0.5),
        z + (Math.random() - 0.5) * 2
      );
      this.scene.add(sMesh);

      this.particles.push({
        mesh: sMesh,
        vx: (Math.random() - 0.5) * 2,
        vy: 2 + Math.random() * 3,
        vz: (Math.random() - 0.5) * 1,
        life: 1.0 + Math.random() * 0.8,
        maxLife: 1.8,
        gravity: 0.5, // floats up
        drag: 0.95,
        scaleDelta: 1.8,
        rotSpeed: (Math.random() - 0.5) * 2,
        type: 'smoke',
      });
    }
  }

  public update(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        if (Array.isArray(p.mesh.material)) {
          p.mesh.material.forEach((m) => m.dispose());
        } else {
          p.mesh.material.dispose();
        }
        this.particles.splice(i, 1);
        continue;
      }

      // Physics update
      p.vx *= p.drag;
      p.vy += p.gravity * dt;
      p.vy *= p.drag;
      p.vz *= p.drag;

      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;

      // Rotation & Scaling
      p.mesh.rotation.x += p.rotSpeed * dt;
      p.mesh.rotation.y += p.rotSpeed * dt;

      const scaleChange = 1 + p.scaleDelta * dt;
      p.mesh.scale.multiplyScalar(Math.max(0.01, scaleChange));

      // Fade out opacity
      const lifeRatio = p.life / p.maxLife;
      const mat = p.mesh.material as THREE.Material & { opacity?: number };
      if (mat.opacity !== undefined) {
        mat.opacity = lifeRatio * 0.8;
      }
    }
  }

  public clear() {
    this.particles.forEach((p) => {
      this.scene.remove(p.mesh);
      p.mesh.geometry.dispose();
    });
    this.particles = [];
  }
}
